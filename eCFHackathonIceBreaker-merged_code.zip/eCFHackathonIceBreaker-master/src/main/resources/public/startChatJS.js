var elem = document.getElementById("b11");
elem.textContent = "Test Text";