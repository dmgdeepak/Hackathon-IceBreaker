package model;

import lombok.Data;

@Data
public class AddInterestRequest {
    private String userName;
    private String interest;
}
