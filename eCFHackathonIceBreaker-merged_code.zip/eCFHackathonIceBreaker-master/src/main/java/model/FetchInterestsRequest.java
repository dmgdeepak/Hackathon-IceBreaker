package model;

import lombok.Data;

@Data
public class FetchInterestsRequest {
    private String userName;
}
